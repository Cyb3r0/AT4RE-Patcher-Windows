Note:
- FSG.EXE is no longer available due to its uncompatibility with Windows 7.
- Place your packer executable file in this directory if you want to use it with AP.